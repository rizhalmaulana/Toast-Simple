package com.dicoding.picodiploma.kulinerku;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Kuliner implements Parcelable{
    private String name, remarks, asal, deskripsi,photo;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getAsal() {
        return asal;
    }

    public void setAsal(String asal) {
        this.asal= asal;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi= deskripsi;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.remarks);
        dest.writeString(this.photo);
        dest.writeString(this.asal);
        dest.writeString(this.deskripsi);
    }

    public Kuliner(){

    }

    protected Kuliner(Parcel in) {
        this.name = in.readString();
        this.remarks = in.readString();
        this.photo = in.readString();
        this.asal = in.readString();
        this.deskripsi = in.readString();
    }

    public static final Parcelable.Creator<Kuliner> CREATOR = new Parcelable.Creator<Kuliner>() {
        @Override
        public Kuliner createFromParcel(Parcel source) {
            return new Kuliner(source);
        }
        @Override
        public Kuliner[] newArray(int size) {
            return new Kuliner[size];
        }
    };

}
