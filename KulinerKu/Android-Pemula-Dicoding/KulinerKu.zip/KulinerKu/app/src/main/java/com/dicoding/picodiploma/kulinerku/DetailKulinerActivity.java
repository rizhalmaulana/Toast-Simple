package com.dicoding.picodiploma.kulinerku;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;


public class DetailKulinerActivity extends AppCompatActivity {
    private static ImageView imgPhoto;
    TextView tvItemName, tvItemRemarks, contentDetail, contentNama, contentHarga, contentAsal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_kuliner);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        imgPhoto = findViewById(R.id.img_photo);
        tvItemName = findViewById(R.id.tv_item_name);
        tvItemRemarks = findViewById(R.id.tv_item_remarks);
        contentDetail = findViewById(R.id.content_detail);
        contentNama = findViewById(R.id.content_nama);
        contentHarga = findViewById(R.id.content_harga);
        contentAsal = findViewById(R.id.content_asal);

        Intent myintent = getIntent();
        String nama = myintent.getExtras().getString("Nama Kuliner");
        String harga = myintent.getExtras().getString("Harga Kuliner");
        String deskripsi = myintent.getExtras().getString("Deskripsi Kuliner");
        String contentkuliner = myintent.getExtras().getString("Content Nama");
        String remarks = myintent.getExtras().getString("Remarks");
        String contentasal = myintent.getExtras().getString("Content Asal");
        int image = myintent.getExtras().getInt("Poto");

        Glide.with(this)
                .load(image)
                .apply(new RequestOptions().override(350, 550))
                .into(DetailKulinerActivity.imgPhoto);
        tvItemName.setText(nama);
        tvItemRemarks.setText(harga);
        contentDetail.setText(deskripsi);
        contentNama.setText(contentkuliner);
        contentHarga.setText(remarks);
        contentAsal.setText(contentasal);
        imgPhoto.setImageResource(image);

        Log.i(deskripsi, "Poto");
        Log.i("Deskripsi", deskripsi);

//        tvItemName.setText(nama);
//        tvItemRemarks.setText(harga);
//        contentDetail.setText(deskripsi);
//        contentNama.setText(contentkuliner);
//        contentHarga.setText(remarks);
//        contentAsal.setText(contentasal);
//        imgPhoto.setImageResource(image);
    }

}

//    private Context context;
//    private ArrayList<Kuliner> listDetail;
//
//    public DetailKulinerActivity(Context context) {
//        this.context = context;
//    }
//
//    @NonNull
//    @Override
//    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
//        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_detail_kuliner, viewGroup, false);
//        return new CardViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull CardViewHolder cardViewHolder, int i) {
//        Kuliner position = getListDetail().get(i);
//        Glide.with(context)
//                .load(position.getPhoto())
//                .apply(new RequestOptions().override(350, 550))
//                .into(cardViewHolder.imgPhoto);
//        cardViewHolder.Kuliner.setText(position.getName());
//        cardViewHolder.Harga.setText(position.getRemarks());
//        cardViewHolder.Deskripsi.setText(position.getDeskripsi());
//        cardViewHolder.Name.setText(position.getName());
//        cardViewHolder.Remarks.setText(position.getRemarks());
//        cardViewHolder.Asal.setText(position.getAsal());
//    }
//
//    @Override
//    public int getItemCount() {
//        return getListDetail().size();
//    }
//
//    public ArrayList<Kuliner> getListDetail() {
//        return listDetail;
//    }
//
//    public void setListDetail(ArrayList<Kuliner> listDetail) {
//        this.listDetail = listDetail;
//    }
//
//    public class CardViewHolder extends RecyclerView.ViewHolder {
//        ImageView imgPhoto;
//        TextView Name, Remarks, Asal, Kuliner, Harga, Deskripsi;
//        public CardViewHolder(@NonNull View itemView) {
//            super(itemView);
//            imgPhoto = itemView.findViewById(R.id.img_photo);
//            Name = itemView.findViewById(R.id.content_nama);
//            Remarks = itemView.findViewById(R.id.content_harga);
//            Deskripsi = itemView.findViewById(R.id.content_detail);
//            Kuliner = itemView.findViewById(R.id.tv_item_name);
//            Harga = itemView.findViewById(R.id.tv_item_remarks);
//
//        }
//    }