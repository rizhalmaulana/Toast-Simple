package com.dicoding.picodiploma.kulinerku;

import java.util.ArrayList;

public class KulinerData {
    public static String[][] data = new String[][]{
            {"Baso Malang", "Rp. 12000", "https://upload.wikimedia.org/wikipedia/commons/b/b6/Baso_Malang_Karapitan.JPG", "Kota Malang", "Baso Malang merupakan makanan yang sudah sangat populer dikalangan para penggemar baso"},
            {"Sate Ayam", "Rp. 14000", "https://upload.wikimedia.org/wikipedia/commons/f/f6/Mutton_satay_from_H._Faqih%2C_Jombang%2C_2017-09-19_02.jpg", "Kota Madura", "Sate Madura merupakan makanan yang sudah sangat populer dikalangan para penggemar sate"},
            {"Gado Gado", "Rp. 10000", "https://upload.wikimedia.org/wikipedia/commons/a/a2/Gado_gado.jpg", "Kota Jakarta", "Gado-Gado merupakan makanan yang sudah sangat populer dikalangan para penggemar gado gado"},
            {"Soto Ayam", "Rp. 12000", "https://upload.wikimedia.org/wikipedia/commons/6/69/Soto_Ayam_home-made.JPG", "Kota Lamongan", "Soto Ayam merupakan makanan yang sudah sangat populer dikalangan para penggemar soto"},
            {"Pecel Lele", "Rp. 16000", "https://upload.wikimedia.org/wikipedia/commons/2/29/Pecel_Lele_1.JPG", "Jawa", "Pecel Lele merupakan makanan yang sudah sangat populer dikalangan para penggemar pecel lele"},
            {"Kerak Telur", "Rp. 15000", "https://upload.wikimedia.org/wikipedia/commons/8/8a/Kerak_Telor.jpg", "Kota Jakarta", "Kerak Telur merupakan makanan yang sudah sangat populer dikalangan para penggemar kerak telur"}
    };

    public static ArrayList<Kuliner> getListData(){
        Kuliner kuliner = null;
        ArrayList<Kuliner> list = new ArrayList<>();
        for (int i = 0; i<data.length; i++) {
            kuliner = new Kuliner();
            kuliner.setName(data[i][0]);
            kuliner.setRemarks(data[i][1]);
            kuliner.setPhoto((data[i][2]));
            kuliner.setAsal(data[i][3]);
            kuliner.setDeskripsi(data[i][4]);

            list.add(kuliner);
        }

        return list;
    }
}
